package encapsulation;
import java.util.Scanner;
public class BankAccess {
    public static void main(String[] args) {
        BankAccount newAccount = new BankAccount("00-02-3536-373", 1000, "Mohammed");
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nBank Account Menu:");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.println("The bank balance is: " + newAccount.getBalance());
                    break;
                case 2:
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    newAccount.deposit(depositAmount);
                    System.out.println("The bank balance is: " + newAccount.getBalance());
                    break;
                case 3:
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawalAmount = scanner.nextDouble();
                    newAccount.withdraw(withdrawalAmount);
                    System.out.println("The bank balance is: " + newAccount.getBalance());
                    break;
                case 4:
                    exit = true;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option. Please choose a valid option.");
            }
        }
        scanner.close();
    }
}

